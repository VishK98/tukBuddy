final List<Map<String, dynamic>> membership = [
  {
    "title": "Free Membership",
    "image": "assets/images/free.png",
  },
  {
    "title": "Preferred Provider Membership",
    "image": "assets/images/member.png",
  },
  {
    "title": "Provider Membership",
    "image": "assets/images/paidMember.png",
  },
];
