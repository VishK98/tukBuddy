List items = [
  {
    "header": "Learn",
    "description":
        "It takes a lot of courage to share your imperfections and even more coursge  to change them.We are exixited for your journey and can't wait to help you with someone who can help",
    "image": "assets/images/W_image.png"
  },
  {
    "header": "Build",
    "description":
        "Before we go further we wanted to let you know at TukBuddy we take your privacy very seriously. We are HIPPA compliant and your information is kept the highest level of security.",
    "image": "assets/images/W_image.png"
  },
  {
    "header": "Launch",
    "description":
        " Your information will only be seen by doctors who also bound by HIPPA. (term and condition with HIPPA laws here?)",
    "image": "assets/images/W_image.png"
  },
];
