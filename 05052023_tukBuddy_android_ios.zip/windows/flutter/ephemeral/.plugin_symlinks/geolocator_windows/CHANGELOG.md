## 0.1.1

- Fixes repository URL of the package.

## 0.1.0

- Adds an initial implementation of Windows support for the geolocator plugin.