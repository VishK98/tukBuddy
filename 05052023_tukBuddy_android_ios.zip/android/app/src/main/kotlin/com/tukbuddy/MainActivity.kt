package com.tukbuddy

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
